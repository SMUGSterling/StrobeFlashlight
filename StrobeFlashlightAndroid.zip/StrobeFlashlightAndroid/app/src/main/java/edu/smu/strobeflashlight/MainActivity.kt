package edu.smu.strobeflashlight

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var cameraManager: CameraManager
    private var cameraIdWithFlash: String? = null

    private lateinit var strobeButton: Button
    private lateinit var steadyButton: Button
    private lateinit var rateSeekBar: SeekBar
    private lateinit var rateText: TextView
    private lateinit var statusText: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var strobeRunning = false
    private var steadyOn = false
    private var torchOn = false
    private var rateHz = 5

    private val requestCameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            statusText.text = "Permission granted. Ready."
        } else {
            statusText.text = "Camera permission is required to control the flashlight."
        }
    }

    private val strobeRunnable = object : Runnable {
        override fun run() {
            if (!strobeRunning) return

            setTorch(!torchOn)

            val halfPeriodMs = max(25L, 1000L / (rateHz * 2L))
            handler.postDelayed(this, halfPeriodMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cameraIdWithFlash = findCameraWithFlash()

        strobeButton = findViewById(R.id.strobeButton)
        steadyButton = findViewById(R.id.steadyButton)
        rateSeekBar = findViewById(R.id.rateSeekBar)
        rateText = findViewById(R.id.rateText)
        statusText = findViewById(R.id.statusText)

        if (cameraIdWithFlash == null) {
            statusText.text = "No flashlight hardware detected on this device."
            strobeButton.isEnabled = false
            steadyButton.isEnabled = false
            return
        }

        ensureCameraPermission()

        updateRateText()

        rateSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                rateHz = progress + 1
                updateRateText()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        strobeButton.setOnClickListener {
            if (!hasCameraPermission()) {
                ensureCameraPermission()
                return@setOnClickListener
            }

            if (strobeRunning) {
                stopStrobe()
            } else {
                startStrobe()
            }
        }

        steadyButton.setOnClickListener {
            if (!hasCameraPermission()) {
                ensureCameraPermission()
                return@setOnClickListener
            }

            stopStrobe()
            steadyOn = !steadyOn
            setTorch(steadyOn)
            steadyButton.text = if (steadyOn) "Turn Off Flashlight" else "Steady Flashlight"
            statusText.text = if (steadyOn) "Steady flashlight is on." else "Ready"
        }
    }

    private fun findCameraWithFlash(): String? {
        return try {
            cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: CameraAccessException) {
            null
        }
    }

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun ensureCameraPermission() {
        if (!hasCameraPermission()) {
            requestCameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun updateRateText() {
        rateText.text = "Rate: $rateHz Hz"
    }

    private fun startStrobe() {
        steadyOn = false
        steadyButton.text = "Steady Flashlight"
        strobeRunning = true
        strobeButton.text = "Stop Strobe"
        statusText.text = "Strobe running at $rateHz Hz."
        handler.post(strobeRunnable)
    }

    private fun stopStrobe() {
        strobeRunning = false
        handler.removeCallbacks(strobeRunnable)
        setTorch(false)
        strobeButton.text = "Start Strobe"
        if (!steadyOn) statusText.text = "Ready"
    }

    private fun setTorch(enabled: Boolean) {
        val id = cameraIdWithFlash ?: return
        try {
            cameraManager.setTorchMode(id, enabled)
            torchOn = enabled
        } catch (e: Exception) {
            statusText.text = "Could not control flashlight: ${e.message ?: "unknown error"}"
            strobeRunning = false
            torchOn = false
        }
    }

    override fun onPause() {
        super.onPause()
        stopStrobe()
        steadyOn = false
        steadyButton.text = "Steady Flashlight"
    }

    override fun onDestroy() {
        stopStrobe()
        super.onDestroy()
    }
}
