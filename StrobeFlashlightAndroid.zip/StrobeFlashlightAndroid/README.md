# Strobe Flashlight Android App

A native Android/Kotlin flashlight strobe app.

## Features

- Start/stop strobe mode
- Adjustable rate from 1 Hz to 20 Hz
- Steady flashlight mode
- Runtime camera permission request
- Flash hardware detection
- Turns the torch off automatically when the app is paused

## Safety

Flashing lights may trigger photosensitive seizures. Do not aim the strobe at people,
drivers, animals, or reflective surfaces.

## How to run

1. Install Android Studio.
2. Open this folder as an Android project.
3. Let Android Studio sync Gradle.
4. Connect an Android device with a flashlight.
5. Press Run.

Android emulators usually do not expose real flashlight hardware, so test on a physical device.

## Requirements

- Android 6.0 / API 23 or newer
- Device with camera flash
